export const EMOJIS = {
  like: "👍",
  love: "❤️",
  funny: "😂",
  wow: "😲",
  sad: "😢",
  angry: "😡",
};
